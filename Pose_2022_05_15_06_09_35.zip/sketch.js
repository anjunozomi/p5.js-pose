//Anju Nozomi Jain
//Body Tracking

let video;
let poseNet;
let pose;
let nose;
let leftEar;
let rightEar;
let leftCheek;
let rightCheek;
let hearts;

function preload() {
  noses = loadImage('nose.png');
  leftCheeks = loadImage('leftCheek.png');
  rightCheeks = loadImage('rightCheek.png');
  leftEars = loadImage('rightEar.png');
  rightEars = loadImage('leftEar.png')
  hearts = loadImage('hearts.png');
}

function setup() {
  createCanvas(640, 480);
  video = createCapture(VIDEO);
  video.size(width,height);
  poseNet = ml5.poseNet(video,modelLoaded);
  poseNet.on("pose", Poses);  
  video.hide();
  
}

function Poses(poses){
    if (poses.length > 0) {
      pose = poses[0].pose;
    }
}

function modelLoaded() {
  console.log('ready');
}

function draw() {
  image(video, 0, 0, width, height);

  if(pose) {
    let nose = pose['nose'];
    let leftEar = pose['leftEar'];
    let rightEar = pose['rightEar'];
    push();
    imageMode(CENTER);
    image(noses,pose.nose.x,pose.nose.y,85,85);
    image(leftCheeks,pose.nose.x-90,pose.nose.y,95,100);
    image(rightCheeks,pose.nose.x+90,pose.nose.y,85,85);
    image(leftEars,pose.leftEar.x,pose.leftEar.y-135,100,100);
    image(rightEars,pose.rightEar.x,pose.rightEar.y-135,100,100);
    image(hearts,pose.nose.x,pose.nose.y+80,400,100);  
    pop();
  }
}